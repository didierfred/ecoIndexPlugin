# Ecoindex V 0.1

Extension for firefox . 

Necessite Firefox V 57 minimum.

Cette extension calcul un ecoindex selon la formule ... 




